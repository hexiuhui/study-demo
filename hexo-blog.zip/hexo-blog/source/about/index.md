---
title: 关于我
layout: "about"
date: 2017-09-07 23:40:52
---

Littlewin，本名「王琪」，89年摩羯男~~伪90后~~
**寻找靠谱的前端Team中，进来的瞅一眼[简历](/resume)**

> Littlewin是一个 [独立博客](http://littlewin.info) 的Owner
> Littlewin目前热情集中在与 [大目标](http://littlewin.info/2016/11/07/Hello,%20%E5%A4%A7%E7%9B%AE%E6%A0%87/) 携手并进和在 [Github](https://github.com/littlewin-wang) 上积极垒砖
> Littlewin目前负责SSD FW开发工作，忙里偷闲转向前端

### 个人特点
> Littlewin看重总结 [2016年终总结](http://littlewin.info/2016/12/30/2016%E5%B9%B4%E7%BB%88%E6%80%BB%E7%BB%93/) ， [To be 27](http://littlewin.info/2016/12/22/To%20be%2027/) 和立FLAG
> Littlewin有时会写诗 [小任性大男孩](http://littlewin.info/2016/10/17/%E5%B0%8F%E4%BB%BB%E6%80%A7%E5%A4%A7%E7%94%B7%E5%AD%A9/) ， [Hello, 大目标](http://littlewin.info/2016/11/07/Hello,%20%E5%A4%A7%E7%9B%AE%E6%A0%87/)
> Littlewin向往单纯和善美，相信 **生活会孕育每一个为之付出了努力的可能**
> Littlewin热情不张扬，相信 **生活也需要近乎无耻的自信**

### 个人爱好
> Littlewin Like making cool things and making cool things with cool guys
> Littlewin是多特死忠，期待有日去威斯特法伦坐在南看台看球
> Littlewin经常参加足球和篮球运动
> Littlewin也喜欢玩游戏：FIFA17、NBA2K17

### 一些声明
> 本站所有文章均为本人原创，仅代表个人在撰文时刻的观点和想法
> 内容转载请保留署名**Littlewin**或指向该原文([http://littlewin.info](http://littlewin.info))的链接，请勿用于商业用途

### 联系方式
- 邮箱: <littlewin.wang@gmail.com>
- 微信: wxoffred
- Github: [Github](https://github.com/littlewin-wang)